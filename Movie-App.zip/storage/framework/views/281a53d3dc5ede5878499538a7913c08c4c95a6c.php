<div class="col-6 col-md-4 col-lg-2 mb-3 mb-lg-3">
    <a href="<?php echo e(route('movie.show',$movie['id'])); ?>" class="mb-3">
        <img src="<?php echo e($movie['poster_path']); ?>" class="img-fluid" alt="poster">
    </a>
    <div class="mt-2">
        <a href="<?php echo e(route('movie.show',$movie['id'])); ?>" class="text-white mb-0 h5 font-weight-bolder text-decoration-none"><?php echo e($movie['title']); ?></a>
        <p class="text-white mb-0">
            <small class="text-primary"><?php echo e($movie['vote_average']); ?></small>
            <?php echo e($movie['release_date']); ?>

        </p>
        <small class="text-white">
            <?php echo e($movie['genres']); ?>

        </small>
    </div>
</div><?php /**PATH D:\Programming Testing\New folder\Movie-App\resources\views/components/movie-card.blade.php ENDPATH**/ ?>