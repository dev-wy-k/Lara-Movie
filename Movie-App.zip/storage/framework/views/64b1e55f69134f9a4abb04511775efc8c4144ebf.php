

<?php $__env->startSection('content'); ?>
 <!-- Popular Actors  -->
 <div class="row justify-content-centr align-items-start mb-3 list">
    <div class="col-12">
        <h3 class="text-primary mb-3">Popular Actors</h3>
    </div>       
    <?php $__currentLoopData = $popularActors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-4 col-lg-3 mb-3 actorCard">
            <div class="mb-2">
                <a href="<?php echo e(route('actors.show', $actor['id'])); ?>" class="">
                    <img src="<?php echo e($actor['profile_path']); ?>" class="img-fluid" alt="">
                </a>
            </div>
            <a href="<?php echo e(route('actors.show', $actor['id'])); ?>" class="mb-0 text-primary text-decoration-none h5"><?php echo e($actor['name']); ?></a>
            <p class="mb-0">
                <small class="text-white"><?php echo e($actor['known_for']); ?></small>
            </p>
        </div> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>  
<!-- Popular Actors End  -->





<div class="scroller-status">
    <div class="d-flex justify-content-center">
        <div class="infinite-scroll-request loader-ellips spinner-border text-primary" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <p class="infinite-scroll-last text-white text-center">End of content</p>
    <p class="infinite-scroll-error text-white text-center">Error</p>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
    <script src="https://unpkg.com/infinite-scroll@4/dist/infinite-scroll.pkgd.min.js"></script>
    <script>
        let elem = document.querySelector('.list');
        let infScroll = new InfiniteScroll( elem, {
            // options
            path: '/actors/page/{{#}}',
            append: '.actorCard',
            status: '.scroller-status',
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming Testing\New folder\Movie-App\resources\views/actors/index.blade.php ENDPATH**/ ?>