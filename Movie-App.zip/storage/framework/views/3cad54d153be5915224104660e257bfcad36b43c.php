

<?php $__env->startSection('content'); ?>
 <!-- Popular Tv Section  -->
 <div class="row justify-content-centr align-items-start mb-3">
        <div class="col-12">
            <h3 class="text-primary mb-3">Popular Shows</h3>
        </div>

        <div class="owl-carousel sliderr owl-theme" >
            <?php $__currentLoopData = $popularTv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tvShow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item p-2 p-md-0">
                    <div class="mb-3 mb-lg-3">
                        <a href="<?php echo e(route('tv.show',$tvShow['id'])); ?>" class="mb-3">
                            <img src="<?php echo e($tvShow['poster_path']); ?>" class="img-fluid" alt="poster">
                        </a>
                        <div class="mt-2">
                            <a href="<?php echo e(route('tv.show',$tvShow['id'])); ?>" class="text-white mb-0 h5 font-weight-bolder text-decoration-none"><?php echo e($tvShow['name']); ?></a>
                            <p class="text-white mb-0">
                                <small class="text-primary"><?php echo e($tvShow['vote_average']); ?></small>
                                <?php echo e($tvShow['first_air_date']); ?>

                            </p>
                            <small class="text-white">
                                <?php echo e($tvShow['genres']); ?>

                            </small>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
                 
        
    </div>
    <!-- Popular Tv Section End  -->

    <!-- Top Rated Show Section  -->

    <div class="row justify-content-center align-items-start">
        <div class="col-12">
            <h3 class="text-primary mb-3">Top Rated Shows</h3>
        </div>

        <?php $__currentLoopData = $topRatedShow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tvShow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if (isset($component)) { $__componentOriginal80f5b95c8947710578ff213f804f57287b4f20c3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TvCard::class, ['tvShow' => $tvShow]); ?>
<?php $component->withName('tv-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal80f5b95c8947710578ff213f804f57287b4f20c3)): ?>
<?php $component = $__componentOriginal80f5b95c8947710578ff213f804f57287b4f20c3; ?>
<?php unset($__componentOriginal80f5b95c8947710578ff213f804f57287b4f20c3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       

    </div>

    
    <div class="row justify-content-between p-3">
        <div class="">
            <?php if($previous): ?>
                <a href="/tv/page/<?php echo e($previous); ?>" class="btn btn-outline-light text-primary">Previous</a>
            <?php endif; ?>
        </div>
        <div class="">
            <?php if($next): ?>
                <a href="/tv/page/<?php echo e($next); ?>" class="btn btn-outline-light text-primary">Next</a>
            <?php endif; ?>
        </div>
    </div> 
    <!-- Top Rated Show Section End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>
<script>
    $(document).ready(function(){
        $('.sliderr').owlCarousel({
            loop:true,
            margin:10,
            responsiveClass:true,
            responsive:{
                0:{
                    items:2,
                    margin:10,
                    autoplay:true,
                    autoplayTimeout: 1500,
                    autoplayHoverPause:true,
                    slideBy:1
                },
                600:{
                    items:3,
                    autoplay:true,
                    autoplayTimeout: 1500,
                    autoplayHoverPause:true,
                    slideBy:1
                },
                1000:{
                    items:6,
                    margin:30,
                    autoplay:true,
                    autoplayTimeout: 2500,
                    autoplayHoverPause:true,
                    slideBy:2
                }
            }
        })
    });
		
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming Testing\New folder\Movie-App\resources\views/tv/index.blade.php ENDPATH**/ ?>