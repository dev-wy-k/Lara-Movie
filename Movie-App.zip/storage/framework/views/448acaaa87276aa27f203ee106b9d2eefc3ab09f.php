

<?php $__env->startSection('content'); ?>
    <!-- Actor Info  -->
    <div class="row justify-content-center align-items-center mb-3">
        <div class="col-10 col-lg-4 mb-5">
            <div class="text-center">
                <div class="">
                    <img src="<?php echo e($actor['profile_path']); ?>" class="img-fluid" alt="">
                </div>

                <div class="d-flex justify-content-center">
                    <?php if($social['facebook']): ?> 
                        <span class="ml-3 mt-3">
                            <a href="<?php echo e($social['facebook']); ?>" title="Facebook" class="text-primary text-decoration-none">
                                <i class="fab fa-facebook fa-2x"></i>
                            </a>
                        </span>
                    <?php endif; ?>
                    
                    <?php if($social['twitter']): ?>
                    <span class="ml-3 mt-3">
                        <a href="<?php echo e($social['twitter']); ?>" title="Twitter" class="text-primary text-decoration-none">
                            <i class="fab fa-twitter fa-2x"></i>
                        </a>
                    </span>
                    <?php endif; ?>

                    <?php if($social['instagram']): ?>                    
                    <span class="ml-3 mt-3">
                        <a href="<?php echo e($social['instagram']); ?>" title="Instagram" class="text-primary text-decoration-none">
                            <i class="fab fa-instagram fa-2x"></i>
                        </a>
                    </span>
                    <?php endif; ?>

                    <?php if($actor['homepage']): ?>                            
                        <span class="ml-3 mt-3">
                            <a href="<?php echo e($actor['homepage']); ?>" title="Website" class="text-primary text-decoration-none">
                                <i class="fas fa-globe-asia fa-2x"></i>
                            </a>
                        </span>
                    <?php endif; ?>
                </div>
            </div>            
        </div>

        <div class="col-12 col-lg-8 mb-5">
            <h2 class="text-primary font-weight-bold"><?php echo e($actor['name']); ?></h2>
            <p class="text-white">
                <span class="text-white">
                    <i class="fas fa-birthday-cake text-primary ml-1"></i>
                    <?php echo e($actor['birthday']); ?> ( <?php echo e($actor['age']); ?> years old ) in <?php echo e(($actor['place_of_birth'])); ?>

                </span>
            </p>

            <p class="text-white my-3 my-md-5">
                <?php echo e($actor['biography']); ?>

            </p>

            <p class="text-primary mb-3">Known For</p>

            <div class="row justify-content-center">
                <?php $__currentLoopData = $knownForMovie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                    <div class="col-6 col-lg-3 ">
                        <a href="<?php echo e($movie['linkToPage']); ?>" class="text-decoration-none text-center">
                            <div class="text-center mb-2">
                                <img src="<?php echo e($movie['poster_path']); ?>" class="img-fluid" alt="poster">
                            </div>
                            <p class="text-white text-nowrap overflow-hidden"><?php echo e($movie['title']); ?></p>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Actor Info End  --> 

    <hr>

    <!-- Credits  -->

    <div class="row my-0">
        <div class="col-12">
            <h3 class="text-primary mb-3">Credits</h3>
        </div>

        <ul class="">
            <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <li class="text-white h5 p-2"><?php echo e($credit['release_year']); ?> &middot; <strong class="text-primary"><?php echo e($credit['title']); ?></strong> <?php echo e($credit['character']); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div>

    <!-- Credits End -->
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programming Testing\New folder\Movie-App\resources\views/actors/show.blade.php ENDPATH**/ ?>