<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('owl/dist/assets/owl.carousel.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('owl/dist/assets/owl.theme.default.css')); ?>">
        <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">
        <link rel="stylesheet" href="/css/app.css">   
        
        <!-- Primary Meta Tags -->
        <title>Movies Website</title>
        <meta name="title" content="Movies Website">
        <meta name="description" content="With Laravel and TMDB API Dev By WYK">

        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="website">
        <meta property="og:url" content="https://metatags.io/">
        <meta property="og:title" content="Movies Website">
        <meta property="og:description" content="With Laravel and TMDB API Dev By WYK">
        <meta property="og:image" content="<?php echo e(asset('meta.png')); ?>">

        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="https://metatags.io/">
        <meta property="twitter:title" content="Movies Website">
        <meta property="twitter:description" content="With Laravel and TMDB API Dev By WYK">
        <meta property="twitter:image" content="<?php echo e(asset('meta.png')); ?>">

        <title>Movie App</title>

        <?php echo $__env->yieldContent('head'); ?>
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="bg-dark">
        <div class="container min-vh-100">
            <div class="row py-2">
                <nav class="navbar navbar-expand-lg navbar-dark w-100">
                    <a class="navbar-brand mr-0 mr-md-3" href="<?php echo e(route('movie.index')); ?>">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-compact-disc fa-2x text-primary mr-2"></i>
                            <span class="text-primary h4 mb-0">Movie App</span>
                        </div>
                    </a>

                    <div class="d-flex align-items-center">
                        <div class="d-block d-lg-none">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-dropdown', [])->html();
} elseif ($_instance->childHasBeenRendered('G38ipWp')) {
    $componentId = $_instance->getRenderedChildComponentId('G38ipWp');
    $componentTag = $_instance->getRenderedChildComponentTagName('G38ipWp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('G38ipWp');
} else {
    $response = \Livewire\Livewire::mount('search-dropdown', []);
    $html = $response->html();
    $_instance->logRenderedChild('G38ipWp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
                        </div>
    
                        <button class="navbar-toggler border-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>  
                    </div>                  

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link text-primary" href="<?php echo e(route('movie.index')); ?>">Movie</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-primary" href="<?php echo e(route('tv.index')); ?>">TV Shows</a>
                            </li> 
                            <li class="nav-item">
                                <a class="nav-link text-primary" href="<?php echo e(route('actors.index')); ?>">Actors</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-primary" href="<?php echo e(route('about.index')); ?>">About</a>
                            </li>                 
                        </ul>
                        <div class="ml-auto d-none d-lg-block">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-dropdown', [])->html();
} elseif ($_instance->childHasBeenRendered('iY2xXv3')) {
    $componentId = $_instance->getRenderedChildComponentId('iY2xXv3');
    $componentTag = $_instance->getRenderedChildComponentTagName('iY2xXv3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iY2xXv3');
} else {
    $response = \Livewire\Livewire::mount('search-dropdown', []);
    $html = $response->html();
    $_instance->logRenderedChild('iY2xXv3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
                        </div>
                    </div>
                </nav>
            </div>
                     <hr>           
            <div class="row py-4 py-lg-5">                
                <div class="container">                        
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

            <div class="text-center text-white p-2">
                <p>
                    Copy Right © 2022 <a href="<?php echo e(route('movie.index')); ?>"class="text-white text-decoration-none">Movie App</a> |
                    Created by <a href="<?php echo e(route('about.index')); ?>" class="text-white text-decoration-none">Wai
                        Yan Kyaw</a>
                </p>
            </div>
        </div>
        
        <?php echo \Livewire\Livewire::scripts(); ?>

        <script src="/js/app.js"></script>
        <script src="<?php echo e(asset('owl/dist/owl.carousel.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('foot'); ?>
    </body>
</html>
<?php /**PATH D:\Programming Testing\New folder\Movie-App\resources\views/layouts/main.blade.php ENDPATH**/ ?>